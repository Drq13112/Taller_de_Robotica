function Inicializacion(PORTNUM,BAUDNUM)

loadlibrary('dynamixel','dynamixel.h');
libfunctions('dynamixel');
res=calllib('dynamixel', 'dxl_initialize',PORTNUM,BAUDNUM);

% res = calllib('dynamixel','dxl_initialize');
if res == 1
    
    ID=0;
    
    % Iniciamos en modo NO rueda, para ello ponermos en la dirección 8
    % el valor de 1023, que indica el rango de movimiento del motor:
    % desde -150 hasta +150 grados
      calllib('dynamixel','dxl_write_word',ID,8,1023);
      
    % Leer posición de un motor (en grados)- dirección 36
      posicion=Leer_posicion_de_motor(ID);
      pause(3);
      
    % Mover el motor a una posición (dada en grados)- dirección 30
      posiciond=0;
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      posiciond=-140; % mover a -140 grados
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      pause(3);
      posiciond=140;
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      posiciond=0;
      pause(3);
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
     
    % Cargar velocidad del motor - dirección 32
    % Máxima velocidad --> velocidad = 1023 (114 rpm --> 684 grados/sg)
    % Mínima velocidad --> velocidad = 1 
    % Velocidad = 0, el motor se mueve a la mayor velocidad posible, no se aplica control de velocidad

      velocidad=512
      calllib('dynamixel','dxl_write_word',ID,32,velocidad);
      posiciond=-140;
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      pause(3);
      posiciond=140;
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      pause(3);
      posiciond=0;
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      
      velocidad=256
      calllib('dynamixel','dxl_write_word',ID,32,velocidad);
      posiciond=-140;
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      pause(3);
      posiciond=140;
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      pause(3);
      posiciond=0;
      calllib('dynamixel','dxl_write_word',ID,30,((posiciond*1024)/300)+511);
      
else
    disp('Failed to open USB2Dynamixel!');
end
unloadlibrary('dynamixel');
end