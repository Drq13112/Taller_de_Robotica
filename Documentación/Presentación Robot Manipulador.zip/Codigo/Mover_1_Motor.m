% Funcion que mueve un motor a una posición y velocidad determinadas,
% estando la posición en grados.
function MueveMotor(ID, PosDeg, Vel)
%if PosDeg <= 0
%   OffsetMotores =[0,-7,-7,0,-5,0, 0]; % Offset en º para corregir la caida por el propio peso
%else
%    OffsetMotores =[0,0,0,0,0,0, 0];
%end
PosDeg = PosDeg+OffsetMotores(ID);
calllib('dynamixel','dxl_write_word',ID,8,1023); % registro de limites de angulos
calllib('dynamixel','dxl_write_word',ID,14,1023); % registro de torque max
calllib('dynamixel','dxl_write_word',ID,32,Vel);% registro de velocidad
calllib('dynamixel','dxl_write_word',ID,30,((PosDeg*1024)/300)+511); % registro de desplazamiento
%pause(0.02);
end