clear
close all;
clc
l1=0.5;l2=0.5;l3=0.5;l4=0.5;l5=0.5;
% 
% q1=0.2;
% q2=30*pi/180;
% q3=40*pi/180;
% q4=-20*pi/180;
% q5=30*pi/180;

miRobot=creaRobot();
% ik = inverseKinematics('RigidBodyTree',miRobot);
% weights = [0.25 0.25 0.25 1 1 1];
% initialguess = miRobot.homeConfiguration;
% MTH_TCP = getMTH_TCP(q1,q2,q3,q4,q5);
% [configSoln,solnInfo] = ik('tool',MTH_TCP,weights,initialguess);
% show(miRobot,configSoln);

gik = generalizedInverseKinematics;
gik.RigidBodyTree = miRobot;

%Cinemática inversa
q0 = homeConfiguration(miRobot); % Initial guess for solver
[q,solutionInfo] = gik(q0);

%Visualización
show(miRobot,q);
title(['Solver status: ' solutionInfo.Status])
% axis([-0.75 0.75 -0.75 0.75 -0.5 1])
% hold on
% plot3([0.0 0.0],[0.5 0.0],[0.5 0.0],'--o')
% hold off


% q1=0.2;
% q2=30*pi/180;
% q3=40*pi/180;
% q4=-20*pi/180;
% q5=30*pi/180;
% getMTH_TCP(q1,q2,q3,q4,q5)

% miRobot = creaRobot();
% endEffector = 'body5';
% q1=0.2;
% q2=30*pi/180;
% q3=40*pi/180;
% q4=-20*pi/180;
% q5=30*pi/180;
% conf = transpose([q1 q2 q3 q4 q5]);
% q0 = homeConfiguration(miRobot);
% show (miRobot, q0);
% MTH0 = getTransform(miRobot, q0, endEffector);
% MTH0

% randConfig = miRobot.randomConfiguration;

%show (miRobot);
%axis([-2,2,-2,2,-2,2]);
% show (miRobot, conf);
% camup([1 0 0]);
%axis([-0.2,2,-2,2,-2,2])
% % Matriz Denavit Hartenberg genérica
% TDH = [ cos(sym('theta')) -sin(sym('theta'))*cos(sym('alpha'))      sin(sym('theta'))*sin(sym('alpha'))     sym('a')*cos(sym('theta'));
%     sin(sym('theta'))  cos(sym('theta'))*cos(sym('alpha'))      -cos(sym('theta'))*sin(sym('alpha'))    sym('a')*sin(sym('theta'));
%     0                   sin(sym('alpha'))                       cos(sym('alpha'))                       sym('d');
%     0                   0                                               0                               1];
% 
% % Nuestra matriz D-H
% DHTABLE = [  pi/2             sym('q1')   0     pi/2;
%              pi/2+sym('q2')     l1+l2     0     pi/2;
%              sym('q3')            0      l3     0;
%              sym('q4')+pi/2       0       0     pi/2;
%              sym('q5')          l4+l5     0     0];
% 
% % Grádos de libertad
% GLD=5;
% 
% %Matrices de paso para cada valor de i
% A = cell(1,GLD);
% for i = 1:GLD
%     alpha = DHTABLE(i,1);
%     d = DHTABLE(i,2);
%     a = DHTABLE(i,3);
%     theta = DHTABLE(i,4);
%     A{i} = subs(TDH);
% end
% 
% %Declaramos una matriz identidad de dimensiones 4x4 como las matrices de
% %paso y que nos servirá para postmultiplicar con cada una de las matrices
% %A{i} e ir almacenando la matriz postmultiplicada
% T = eye(4);
% for i=1:GLD
%     T = T*A{i};
% end
% 
% %Utilizamos la función simplify para simplificar la ecuación final
% MTH = simplify(T);

% DHTABLE = [  pi/2             sym('q1')   0     pi/2;
%              pi/2+sym('q2')     l1+l2     0     pi/2;
%              sym('q3')            0      l3     0;
%              sym('q4')+pi/2       0       0     pi/2;
%              sym('q5')          l4+l5     0     0];

% %Inserting D-H convention parameters
% a1 = 0; alpha1 = pi/2; t1 = pi/2;
% a2 = 0; alpha2 = pi/2; d2 = l1+l2; 
% a3 =l3; alpha3 = 0; d3 = 0;
% a4 = 0; alpha4 = pi/2; d4= 0;
% a5 = 0; alpha5 = 0; d5 = l4+l5;
% 
% % Inserting joint limits for Arms
% d1_min = 0;           d1_max = 0;
% t2_min = -150*pi/180; t2_max = 150*pi/180;
% t3_min = -150*pi/180; t3_max = 150*pi/180; 
% t4_min = -150*pi/180; t4_max = 150*pi/180;
% t5_min = -180*pi/180; t5_max = 150*pi/180;
% 
% % Monte Carlo method 
% % sampling size
% N = 2000;
% d1 = d1_min + (d1_max-d1_min)*rand(N,1);
% t2 = t2_min + (t2_max-t2_min)*rand(N,1);
% t3 = t3_min + (t3_max-t3_min)*rand(N,1);
% t4 = t4_min + (t4_max-t4_min)*rand(N,1);
% t5 = t5_min + (t5_max-t5_min)*rand(N,1);
% 
% for i = 1:N
% A1 = TransMat(a1,alpha1,d1(i),t1);
% A2 = TransMat(a2,alpha2,d2,t2(i));
% A3 = TransMat(a3,alpha3,d3,t3(i));
% A4 = TransMat(a4,alpha4,d4,t4(i));
% A5 = TransMat(a5,alpha5,d5,t5(i));
% T = A1*A2*A3*A4*A5;
% X=T(1,4);
% Y=T(2,4);
% Z=T(3,4);
% plot3(X,Y,Z,'.r')
% hold on;
% end
% 
% xlabel('X');
% ylabel('Y');
% zlabel('Z');

% miRobot = creaRobot(l1,l2,l3,l4,l5);



% showdetails(miRobot);
% endEffector = 'body5';
% q0 = homeConfiguration(miRobot);
% MTH0 = getTransform(miRobot, q0, endEffector);
% 
% MTH0



% n=5;
% %Se definen los valores que pueden tomar las articulaciones 
% q1=linspace(0, 1, n);%Distancia en metros
% q2=linspace(-150, 150, n)*pi/180;%Giro en radianes
% q3=linspace(-150, 150, n)*pi/180;
% q4=linspace(-150, 150, n)*pi/180;
% q5=linspace(-180, 180, n)*pi/180;
% 
% [q1,q2,q3,q4,q5]=ndgrid(q1,q2,q3,q4,q5);


% % Posición del TCP
% X= round(subs(MTH(1,4)),2);
% Y= round(subs(MTH(2,4)),2);
% Z= round(subs(MTH(3,4)),2);


% figure();
% plot3(X(:),Y(:),Z(:),'b.');
% hold on;
% xlabel('X');
% ylabel('Y');
% zlabel('Z');
% 
% title('Espacio de trabajo del robot','fontWeight','bold')
% hold on;
% xlabel('X','FontWeight','bold');
% ylabel('Y','FontWeight','bold');
% zlabel('Z','FontWeight','bold');
% zlim([0 inf]);
% robot.plot([0,0,0,0,0]);
% 
% workspace=gca(figura);