function MTH_TCP = getMTH_TCP(q1,q2,q3,q4,q5)
    miRobot = creaRobot();
    conf = transpose([q1 q2 q3 q4 q5]);
    endEffector = 'tool';
    MTH_TCP = getTransform(miRobot, conf, endEffector);
end