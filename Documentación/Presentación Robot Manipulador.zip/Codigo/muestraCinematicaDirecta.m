function muestraCinematicaDirecta(q1,q2,q3,q4,q5)
    miRobot = creaRobot();
    conf = transpose([q1 q2 q3 q4 q5]);
    show (miRobot, conf);
    camup([1 0 0]);
end