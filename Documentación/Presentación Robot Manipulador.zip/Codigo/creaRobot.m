function myRobot=creaRobot()
%Distancias entre cuerpos
l1=0.1725;l2=0.08898;l3=0.260486;a4_=0.0145;a5_=0.001853;d3_=0.005327;d4_=0.006194;

%Limites de las articulaciones
joint1Limits = [0 0.25];
joint2Limits = [-150*pi/180 150*pi/180];
joint3Limits = [0*pi/180    180*pi/180];
joint4Limits = [-60*pi/180  110*pi/180];
%Instancio mi robot con la funcion rigidBodyTree
myRobot = rigidBodyTree('DataFormat','column');

%% Cuerpo 1
body1 = rigidBody('body1'); %Crear un objeto de sólido rígido 
jnt1 = rigidBodyJoint('jnt1','prismatic');  %Crear la articulación. 
jnt1.JointAxis = [0 1 0];   %Eje de movimiento de la articulación. 
jnt1.HomePosition = 0;  %Posicíon por defecto 
jnt1.PositionLimits = joint1Limits;
%Defina la posición relativa del nuevo eslabón 
tform = trvec2tform([0, 0, 0])*axang2tform([0 1 0 pi/2])*axang2tform([0 0 1 pi/2]);          
setFixedTransform(jnt1,tform);
%Defina el angulo inicial de la articulación
body1.Joint = jnt1; 
%Agregue el primer cuerpo al árbol. Especifique que lo está adjuntando a la base del árbol. La transformación fija definida anteriormente es de la base (principal) al primer cuerpo.
addBody(myRobot,body1,'base');

%% Cuerpo 2 (Auxiliar)
body2 = rigidBody('body2'); 
jnt2 = rigidBodyJoint('jnt2','revolute');
jnt2.JointAxis = [0 0 1];   %Eje de movimiento de la articulación. 
jnt2.HomePosition = 0;  %Defina la posicíon por defecto
jnt2.PositionLimits = joint2Limits;
tform2 = trvec2tform([0, 0, 0]);  %converts the Cartesian representation of a translation vector, trvec, to the corresponding homogeneous transformation, tform. 
setFixedTransform(jnt2,tform2);
body2.Joint = jnt2; 
addBody(myRobot,body2,'body1'); % Add body2 to body1


%% Cuerpo 3
body3 = rigidBody('body3'); 
jnt3 = rigidBodyJoint('jnt3','revolute');
jnt3.JointAxis = [0 0 1];   %Eje de movimiento de la articulación. 
jnt3.HomePosition = 0;  %Defina la posicíon por defecto
jnt3.PositionLimits = joint3Limits;
tform3 = trvec2tform([0, 0, l1])*axang2tform([1 0 0 pi/2])*axang2tform([0 1 0 pi/2]);  %converts the Cartesian representation of a translation vector, trvec, to the corresponding homogeneous transformation, tform. 
setFixedTransform(jnt3,tform3);
body3.Joint = jnt3; 
addBody(myRobot,body3,'body2'); % Add body3 to body2

%% Cuerpo 4
body4 = rigidBody('body4'); 
jnt4 = rigidBodyJoint('jnt4','revolute');
jnt4.JointAxis = [0 0 1];   %Eje de movimiento de la articulación. 
jnt4.HomePosition = 0;  %Defina la posicíon por defecto 
jnt4.PositionLimits = joint4Limits;
tform4 = trvec2tform([l2, 0, 0])*axang2tform([0 0 1 pi])*trvec2tform([0, 0, d3_]);  %converts the Cartesian representation of a translation vector, trvec, to the corresponding homogeneous transformation, tform. 
setFixedTransform(jnt4,tform4);
body4.Joint = jnt4; 
addBody(myRobot,body4,'body3'); % Add body4 to body3

%% Cuerpo 5
body5 = rigidBody('body5'); 
jnt5 = rigidBodyJoint('jnt5','revolute');
jnt5.JointAxis = [0 0 1];   %Eje de movimiento de la articulación. 
jnt5.HomePosition = 0;  %Defina la posicíon por defecto 
%No tiene límite en la articulacion porque la muñeca es capaz de realizar
%giros ilimitados.
tform5 = axang2tform([0 1 0 -pi/2])*axang2tform([0 0 1 -pi/2])*trvec2tform([a4_, -d4_, 0]);  %converts the Cartesian representation of a translation vector, trvec, to the corresponding homogeneous transformation, tform. 
setFixedTransform(jnt5,tform5);
body5.Joint = jnt5; 
addBody(myRobot,body5,'body4'); % Add body5 to body4

%% TCP
body6 = rigidBody('tool'); 
jnt6 = rigidBodyJoint('jnt6','fixed');
tform6 = trvec2tform([a5_, 0, l3])*axang2tform([0 0 1 pi]);  %converts the Cartesian representation of a translation vector, trvec, to the corresponding homogeneous transformation, tform. 
setFixedTransform(jnt6,tform6);
body6.Joint = jnt6; 
addBody(myRobot,body6,'body5'); % Add tool to body5
end