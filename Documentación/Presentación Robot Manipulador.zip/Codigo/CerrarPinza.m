function AbrirPinza()
end