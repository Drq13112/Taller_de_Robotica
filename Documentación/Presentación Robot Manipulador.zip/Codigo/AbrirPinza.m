function AbrirPinza()
end
